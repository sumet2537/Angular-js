var app = angular.module('hotelApp', ['ui.router']);

app.config(function ($stateProvider, $httpProvider, $urlRouterProvider) {
    $httpProvider.interceptors.push('responseObserver');
    $urlRouterProvider.otherwise('/home');
    $stateProvider
        .state('home', {
            url: '/home',
            templateUrl: 'templates/home.html'
        })

    .state('register', {
            url: '/register',
            templateUrl: 'templates/register.html',
            controller: 'registerController'
        })
    .state('login', {
        url: '/login',
        templateUrl: 'templates/login.html',
        controller: 'loginController'
    })
    .state('profile', {
        url: '/profile',
         resolve: {
            callProfile: function($userService) {
                return $userService.callProfile();
            }
        },
        templateUrl: 'templates/profile.html',
        controller: 'userProfileController'
    })
    .state('editProfile', {
        url: '/edit-profile',
        resolve: {
            callProfile: function($userService) {
                return $userService.callProfile();
            }
        },
        templateUrl: 'templates/edit-profile.html',
        controller: 'editProfileController'
    })
    .state('booking', {
        url: '/booking',
        resolve: {
            callRooms: function($booking) {
                return $booking.callRooms();
            }
        },
        templateUrl: 'templates/booking.html',
        controller: 'bookingController'
    })
    .state('mybooking', {
        url: '/mybooking',
        resolve: {
            callMyBooking: function($booking) {
                return $booking.callMyBooking();
            }
        },
        templateUrl: 'templates/mybooking.html',
        controller: 'myBookingController'
    });
});

app.run(function ($security) {
    $security.checkAuth();
});
app.service('$security', function ($http, $state, $rootScope) {
    this.checkAuth = function () {
        $http.post('checkauth.php')
            .then(function (resp) {
                if (resp.data !== undefined) {
                    if (resp.data.status !== undefined && resp.data.status === 'success') {
                        $rootScope.userLogin = true;
                        $rootScope.menus = $rootScope.memberMenus;
                    }
                }
            });
    }
    this.register = function (user) {
        $http.post('register.php', user)
            .then(function (resp) {
                if (resp.data !== undefined) {
                    if (resp.data.message !== undefined) {
                        alert(resp.data.message);
                    }
                    if (resp.data.status !== undefined && resp.data.status === 'success') {
                        $state.go('login');
                    }
                }
            }, function (resp) {
                alert('Has an error occurred');
            });
    }
    this.login = function (username, password) {
        $http.post('login.php', {
                username: username,
                password: password
            })
            .then(function (resp) {
                if (resp.data.message !== undefined) {
                    alert(resp.data.message);
                }
                if (resp.data.status !== undefined && resp.data.status === 'success') {
                    $rootScope.userLogin = true;
                    $rootScope.menus = $rootScope.memberMenus;
                    $state.go('home');
                }
            }, function (resp) {
                alert('Has an error occurred');
            });
    }
    this.logout = function () {
        $http.post('logout.php', {})
            .then(function (resp) {
                if (resp.data !== undefined) {
                    if (resp.data.message !== undefined) {
                        alert(resp.data.message);
                    }
                    if (resp.data.status !== undefined && resp.data.status === 'success') {
                        $rootScope.userLogin = false;
                        $rootScope.menus = $rootScope.guestManus;
                        $state.go('login');
                    }
                }
            }, function () {});
    }
});

app.factory('responseObserver', function ($location) {
    return {
        response: function (response) {
            return response;
        },
        responseError: function (response) {
            switch (response.status) {
            case 401:
                $location.path('/login');
                break;
            case 404:
                return {
                    data: 'Page not found',
                    status: 200,
                    statusText: 'OK'
                };
            case 500:
                return {
                    data: 'Internal server error',
                    status: 200,
                    statusText: 'OK'
                };
            }
        }
    };
});

app.controller('registerController', function ($scope, $http, $state, $security, $rootScope) {
    $scope.user = {};
    $scope.register = function () {
        $security.register($scope.user);
    }

    if ($rootScope.userLogin) {
        $state.go('home');
    }
});

app.controller('loginController', function ($scope, $http, $state, $security, $rootScope) {
    $scope.user = {};
    $scope.login = function () {
        $security.login($scope.user.username, $scope.user.password);
    }

    if ($rootScope.userLogin) {
        $state.go('home');
    }
});
app.controller('userProfileController', function($scope, callProfile, $state){
    $scope.user = callProfile;
    $scope.edit = function(){
        $state.go('editProfile');
    }
});
app.controller('editProfileController', function($scope, callProfile, $userService){
    $scope.user = callProfile;
    $scope.user.birthday = new Date($scope.user.birthday);
    $scope.edit = function(){
        $userService.updateProfile($scope.user);
    }
});

 app.controller('myBookingController', function($scope, callMyBooking, $booking) {
    $scope.bookingLists = callMyBooking;
    $scope.cancel = function(id) {
        $booking.cancelBookingRoom(id)
        .then(function(resp) {
            if(resp !== undefined) {
                if(resp.message !== undefined) {
                    alert(resp.message);
                }
            }
            var bLists = $booking.callMyBooking();
            bLists.then(function(resp) {
                $scope.bookingLists = resp;
            }, function(resp) {
                console.log(resp);
            });
        });
    }
});
app.controller('bookingController', function($scope, callRooms, $http, $booking) {
    $scope.rooms = callRooms;
    $scope.booking = {};
    $scope.changeInfo = function() {
        $scope.booking.room = '';
    }
    $scope.checkRoom = function() {
        if ($scope.booking.check_in_date === undefined) {
            $scope.booking.room = '';
            alert('กรุณาระบุวันที่เข้าพัก');
        } else if ($scope.booking.check_out_date === undefined) {
            $scope.booking.room = '';
            alert('กรุณาระบุวันที่สิ้นสุด');
        } else {
            var startDate = new Date($scope.booking.check_in_date);
            var endDate = new Date($scope.booking.check_out_date);
            if(startDate.getTime() <= endDate.getTime()) {
                var diff = endDate.getTime() - startDate.getTime();
                diff = Math.floor(diff / (1000 * 60 * 60 * 24));
                diff = diff + 1;
            } else {
                alert('วันที่เข้าพักต้องน้อยกว่าหรือเท่ากันวันที่ checkout');
                $scope.booking.room = '';
                $scope.booking.check_in_date = '';
                $scope.booking.check_out_date = '';
                return;
            }
            
            $scope.booking.days = diff;
            $http.post('checkroom.php', {
                room_id: $scope.booking.room,
                check_in_date: $scope.booking.check_in_date,
                check_out_date: $scope.booking.check_out_date
            })
            .then(function(resp) {
                if(resp !== undefined && resp.data !== undefined) {
                    var data = resp.data;
                    if(data.data !== undefined && data.data.length > 0) {
                        $scope.booking.room = '';
                        alert('ห้องที่คุณเลือกไม่ว่าง');
                    }
                }
            }, function(resp){
                
            });
        }
    }
    $scope.btnBooking = function() {
        $booking.bookingRoom($scope.booking);
    }
});


app.directive('logout', function ($http, $security) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            element.bind('click', function () {
                $security.logout();
            });
        }
    }
});
app.run(function ($security, $rootScope) {
    $security.checkAuth();
    $rootScope.userLogin = false;
    $rootScope.guestManus = [
        { route_name: 'login', route_label: 'login'   },
        {route_name: 'register', route_label: 'Register' }
    ];
    $rootScope.memberMenus = [
        { route_name: 'home', route_label: 'Home'},
        {route_name: 'profile', route_label: 'Profile' },
        {route_name: 'booking', route_label: 'Booking'},
        {route_name: 'mybooking', route_label: 'My Booking'}
    ];
    $rootScope.menus = $rootScope.guestManus;
});
app.directive('passwordConfirmation', function () {
    return {
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            if (!attrs.passwordConfirmation) {
                console.error('passwordConfirmation expects a model as an argument!');
                return;
            }
            scope.$watch(attrs.passwordConfirmation, function (value) {
                if (ctrl.$viewValue !== undefined && ctrl.$viewValue !== '') {
                    ctrl.$setValidity('passwordConfirmation', value === ctrl.$viewValue);
                }
            });
            ctrl.$parsers.push(function (value) {
                if (value === undefined || value === '') {
                    ctrl.$setValidity('passwordConfirmation', true);
                    return value;
                }
                var isValid = value === scope.$eval(attrs.passwordConfirmation);
                ctrl.$setValidity('passwordConfirmation', isValid);
                return isValid ? value : undefined;
            });
        }
    };
});
app.service('$userService', function($http, $q, $state) {
    this.callProfile = function() {
        var defer = $q.defer();
        $http.post('profile.php', {})
        .then(function(resp) {
            if(resp !== undefined && resp.data !== undefined) {
                var msg = resp.data.message !== undefined ? resp.data.message : 'Has an error occurred';
                if(resp.data.status !== undefined && resp.data.status === 'success') {
                    var profile = resp.data.profile;
                    if(profile !== undefined && profile !== null) {
                        defer.resolve(profile);
                    }
                } else {
                    defer.reject(msg);
                }
            }
        }, function(resp) {
            defer.reject('Has an error occurred');
        });
        return defer.promise;
    }
    
    this.updateProfile = function(user) {
        if(user !== undefined && user !== null) {
            $http.post('updateprofile.php', user)
            .then(function(resp) {
                if(resp !== undefined && resp.data !== undefined) {
                    if(resp.data.message !== undefined) {
                        alert(resp.data.message);
                    }
                    if(resp.data.status !== undefined && resp.data.status === 'success') {
                        $state.go('profile');
                    }
                }
            }, function(resp) {
                alert('Has an error occurred');
            });
        }
    }
});

app.service('$booking', function($http, $q, $state) {
    this.callMyBooking = function() {
        var defer = $q.defer();
        $http.post('mybooking.php', {})
        .then(function(resp) {
            if(resp !== undefined && resp.data !== undefined) {
                var status = (resp.data.status !== undefined) ? resp.data.status : 'error';
                if(status === 'success') {
                    defer.resolve(resp.data.data);
                } else if (status === 'warning') {
                    defer.resolve([]);
                } else {
                    defer.reject('No data found.');
                }
            }
        }, function(resp) {
            defer.reject('Has an error occurred.');
        });
        return defer.promise;
    }
    
    this.callRooms = function() {
        var defer = $q.defer();
        $http.post('rooms.php', {})
        .then(function(resp) {
            if(resp !== undefined && resp.data !== undefined) {
                var status = (resp.data.status !== undefined) ? resp.data.status : 'error';
                if(status === 'success') {
                    defer.resolve(resp.data.data);
                } else if (status === 'warning') {
                    defer.resolve([]);
                } else {
                    defer.reject('No data found.');
                }
            }
        }, function(resp) {
            defer.reject('Has an error occurred.');
        });
        return defer.promise;
    }
    
    this.bookingRoom = function($bookingInfo) {
        $http.post('booking.php', $bookingInfo)
        .then(function(resp) {
            if(resp !== undefined && resp.data !== undefined) {
                if(resp.data.message !== undefined) {
                    alert(resp.data.message);
                }
                if(resp.data.status !== undefined && resp.data.status === 'success') {
                    $state.go('mybooking');
                }
            }
        }, function() {
            alert('Has an error occurred.');
        });
    }
    
    this.cancelBookingRoom = function($bookingId) {
        var defer = $q.defer();
        $http.post('cancelbooking.php', {booking_id: $bookingId})
        .then(function(resp) {
            if(resp !== undefined && resp.data !== undefined) {
                defer.resolve(resp.data);
            }
        }, function() {
            defer.reject('Has an error occurred.');
        });
        return defer.promise;
    }
});

