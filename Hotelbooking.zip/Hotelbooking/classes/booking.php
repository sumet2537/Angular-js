<?php
require_once str_replace('booking.php', '', __FILE__) . 'security.php';

class Booking {
    
    private $sec;
    private $db;
    
    public function __construct() {
        $this->sec = new Security();
        $this->db = new dbHelper();
    }
    //เรียก ข้อมูลจากดาต้าเบสขึ้นมาโชที่ไฟ mybooking.php และต้องไปเพิ่มข้อมูลที่ไฟ mybooking.html
    public function myBooking() {
        $sql = "SELECT r.id, rm.room_name, r.days, DATE_FORMAT(r.check_in_datetime, '%d/%m/%Y') AS check_in_date, DATE_FORMAT(r.check_out_datetime, '%d/%m/%Y') AS check_out_date FROM `" . DB_TABLE_RENT . "` AS r, `" . DB_TABLE_ROOM . "` AS rm WHERE r.room_id = rm.room_id AND r.uid = " . $this->sec->getUserId();
        return $this->db->query($sql);
    }
    
    public function bookingRoom($booking) {
        $rows = $this->db->insert(DB_TABLE_RENT, [
            'uid' => $booking['uid'],
            'room_id' => $booking['room_id'],
            'days' => $booking['days'],
            'check_in_datetime' => $booking['check_in_datetime'],
            'check_out_datetime' => $booking['check_out_datetime']
        ], ['uid', 'room_id', 'days', 'check_in_datetime', 'check_out_datetime']);
        return $rows;
    }
    
    public function cancelBooking($bookingId) {
        return $this->db->delete(DB_TABLE_RENT, ['id' => $bookingId]);
    }
    
    public function rooms() {
        return $rows = $this->db->select(DB_TABLE_ROOM, []);
    }
    
    public function findRentByUid($uid) {
        return $this->db->select(DB_TABLE_RENT, ['uid' => $uid, 'checkout' => 'N']);
    }
    
    public function checkRoom($roomId, $startDate, $endDate) {
        $sql = "SELECT * FROM `rents` WHERE ((`check_in_datetime` BETWEEN '" . $startDate . "' and '" . $startDate . "' OR `check_in_datetime` = '" . $startDate . "') OR (`check_out_datetime` BETWEEN '" . $endDate . "' AND '" . $endDate . "' OR `check_out_datetime` = '" . $endDate . "')) AND `room_id` = '" . $roomId . "' AND `checkout` = 'N'";
        
        return $this->db->query($sql);
    }
    
}