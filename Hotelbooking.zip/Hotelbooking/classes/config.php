<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_HOST', 'localhost');
define('DB_NAME', 'hotelbooking');

define('DB_TABLE_USER', 'users');
define('DB_TABLE_ROOM', 'rooms');
define('DB_TABLE_RENT', 'rents');

?>
