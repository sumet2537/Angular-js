<?php
header("Access-Control-Allow-Origin: *");
require_once str_replace('security.php', '', __FILE__) . 'dbHelper.php';
session_start();

class Security {
    
    private $db;
    
    public function __construct() {
        $this->db = new dbHelper();
    }
    
    public function checkAuth() {
        $username = '';
        if(isset($_SESSION['username'])) {
            $username = $_SESSION['username'];
        }
        if(!empty($username)) {
            return ['status' => 'success', 'message' => 'Logged In.'];
        }
        header('HTTP/1.1 401 Unauthorized', true, 401);
        return ['status' => 'error', 'message' => 'No logged in.'];
    }
    
    public function getUsername() {
        return $username = $_SESSION['username'];
    }
    
    public function getUserId() {
        return $username = $_SESSION['uid'];
    }
    
    public function register($user) {
        if(is_array($user)) {
            $row = $this->db->insert(DB_TABLE_USER, [
                'username' => $user['username'],
                'password' => md5($user['password']),
                'email' => $user['email'],
                'firstname' => $user['firstname'],
                'lastname' => $user['lastname']
            ], ['username', 'password', 'email', 'firstname', 'lastname']);
            return $row;
        } else {
            return ['status' => 'error', 'message' => 'Register error.'];
        }
    }
    
    public function login($username, $password) {
        if(empty($username)) {
            return ['status' => 'error', 'message' => 'Please enter username.'];
        } else if (empty($password)) {
            return ['status' => 'error', 'message' => 'Please enter password.'];
        } else {
            $row = $this->db->select(DB_TABLE_USER, ['username' => $username, 'password' => md5($password)]);
            if(isset($row['status']) && $row['status'] == 'success') {
                $_SESSION['uid'] = $row['data'][0]['uid'];
                $_SESSION['username'] = $row['data'][0]['username'];
                return ['status' => 'success', 'message' => 'Login success.'];
            } else {
                return ['status' => 'error', 'message' => 'Login error. Please check your username or password.'];
            }
        }
    }
    
    public function logout() {
        $_SESSION['uid'] = '';
        $_SESSION['username'] = '';
        return ['status' => 'success', 'message' => 'Logout success.'];
    }
    
    public function profile() {
        $user_id = isset($_SESSION['uid']) ? $_SESSION['uid'] : 0;
        $findUser = $this->db->select(DB_TABLE_USER, ['uid' => $user_id]);
        if($findUser['status'] == 'success') {
            $user = $findUser['data'][0];
            $user['password'] = '';
            return ['status' => 'success', 'message' => 'Success', 'profile' => $user];
        } else {
            return ['status' => 'error', 'message' => 'No user session. Please login first.'];
        }
    }
    
    public function updateProfile($user) {
        if(is_array($user)) {
            $update = $this->db->update(DB_TABLE_USER, [
                'email' => $user['email'],
                'firstname' => $user['firstname'],
                'lastname' => $user['lastname'],
                'age' => $user['age'],
                'birthday' => $user['birthday'],
                'address' => $user['address']
            ], [
                'uid' => $user['uid']
            ], ['email', 'firstname', 'lastname', 'age', 'birthday', 'address']);
            return $update;
        } else {
            return ['status' => 'error', 'message' => 'Update profile error.'];
        }
    }
}